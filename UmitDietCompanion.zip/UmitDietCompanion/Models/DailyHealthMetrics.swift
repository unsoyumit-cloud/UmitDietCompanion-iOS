//
//  DailyMetrics.swift
//  UmitDietCompanion
//
//  Created by Ümit Ünsoy on 2.07.2026.
//

import Foundation

struct DailyHealthMetrics {

    var dailySteps: Int

    var dailyWaterIntake: Int

    var dailyCalorieIntake: Int

    var dailyCalorieBurned: Int

    var sleepHours: Double

    var restingHeartRate: Int

    var currentWeight: Double

}
