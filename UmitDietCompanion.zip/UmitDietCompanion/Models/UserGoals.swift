//
//  UserGoals.swift
//  UmitDietCompanion
//
//  Created by Ümit Ünsoy on 9.07.2026.
//

//
//  UserGoals.swift
//  UmitDietCompanion
//

import Foundation

struct UserGoals {

    var water: Double
    var steps: Int
    var energy: Int
    var sleep: Double
    var weight: Double

}
