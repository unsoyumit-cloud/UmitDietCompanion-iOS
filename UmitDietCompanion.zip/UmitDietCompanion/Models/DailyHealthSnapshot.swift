//
//  DailyHealthSnapshot.swift
//  UmitDietCompanion
//
//  Created by Ümit Ünsoy on 12.07.2026.
//

import SwiftUI

struct DailyHealthSnapshot: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    DailyHealthSnapshot()
}
