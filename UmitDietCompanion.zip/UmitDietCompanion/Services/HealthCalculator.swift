//
//  HealthCalculator.swift
//  UmitDietCompanion
//
//  Created by Ümit Ünsoy on 5.07.2026.
//

import Foundation

struct HealthCalculator {

    // MARK: - Sleep

    static func sleepProgress(
        sleepHours: Double,
        goal: Double
    ) -> Double {

        guard goal > 0 else { return 0 }

        return min(sleepHours / goal, 1.0)
    }

    // MARK: - Water

    static func waterProgress(
        consumed: Int,
        goal: Int
    ) -> Double {

        guard goal > 0 else { return 0 }

        return min(Double(consumed) / Double(goal), 1.0)
    }

    // MARK: - Heart Rate

    static func heartRateProgress(
        restingHeartRate: Int
    ) -> Double {

        Double(restingHeartRate) / 100
    }

    // MARK: - Weight

    static func lostWeight(
        profile: UserProfile,
        today: DailyHealthMetrics
    ) -> Double {

        profile.startWeight - today.currentWeight
    }

    static func remainingWeight(
        profile: UserProfile,
        today: DailyHealthMetrics
    ) -> Double {

        max(today.currentWeight - profile.targetWeight, 0)
    }

    static func weightProgress(
        profile: UserProfile,
        today: DailyHealthMetrics
    ) -> Double {

        let totalToLose = profile.startWeight - profile.targetWeight

        guard totalToLose > 0 else { return 0 }

        let lost = profile.startWeight - today.currentWeight

        return min(max(lost / totalToLose, 0), 1)
    }

    // MARK: - Calories

    static func calorieProgress(
        intake: Int,
        goal: Int
    ) -> Double {

        guard goal > 0 else { return 0 }

        return min(Double(intake) / Double(goal), 1.0)
    }

    static func calorieBalance(
        intake: Int,
        burned: Int
    ) -> Int {

        burned - intake
    }

    // MARK: - BMI

    static func bmi(
        weight: Double,
        heightInCm: Double
    ) -> Double {

        let height = heightInCm / 100

        guard height > 0 else { return 0 }

        return weight / (height * height)
    }
}
