//
//  Services     DashboardInsightService.swift
//  UmitDietCompanion
//
//  Created by Ümit Ünsoy on 5.07.2026.
//

import Foundation

struct DashboardInsightService {

    static func generateInsight(
        today: DailyHealthMetrics,
        profile: UserProfile
    ) -> String {

        var messages: [String] = []

        let remainingWater =
            max(profile.dailyWaterIntakeGoal - today.dailyWaterIntake, 0)

        if remainingWater > 0 {
            messages.append("💧 \(remainingWater) ml su kaldı.")
        }

        let remainingSteps =
            max(profile.dailyStepGoal - today.dailySteps, 0)

        if remainingSteps > 0 {
            messages.append("🚶 \(remainingSteps) adım kaldı.")
        }

        let remainingSleep =
            max(profile.sleepGoal - today.sleepHours, 0)

        if remainingSleep > 0 {
            messages.append(
                String(format: "😴 %.1f saat daha uyku hedefin var.",
                       remainingSleep)
            )
        }

        if messages.isEmpty {
            return "🎉 Bugünkü tüm hedeflerini tamamladın!"
        }

        return messages.joined(separator: "\n")
    }
}
