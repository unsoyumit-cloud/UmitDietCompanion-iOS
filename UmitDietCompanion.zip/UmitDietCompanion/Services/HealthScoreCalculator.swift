//
//  HelathScoreCalculator.swift
//  UmitDietCompanion
//
//  Created by Ümit Ünsoy on 5.07.2026.
//

import Foundation

struct HealthScoreCalculator {

    static func progress(current: Double, target: Double) -> Double {

        guard target > 0 else { return 0 }

        return min(current / target, 1.0)
    }
    static func waterScore(current: Double, target: Double) -> Int {

        Int(progress(current: current, target: target) * 20)
    }
    
    static func totalScore(
        water: Int,
        steps: Int,
        sleep: Int,
        heart: Int,
        energy: Int
    ) -> Int {

        water + steps + sleep + heart + energy
    }
    
    static func energyProgress(current: Double, target: Double) -> Double {
        progress(current: current, target: target)
    }

    static func sleepProgress(current: Double, target: Double) -> Double {
        progress(current: current, target: target)
    }

    static func weightProgress(current: Double, target: Double) -> Double {

        guard current > 0 else { return 0 }

        return min(target / current, 1.0)
    }

    static func heartProgress(current: Double) -> Double {

        switch current {

        case 55...65:
            return 1.0

        case 50..<55:
            return 0.9

        case 66...70:
            return 0.9

        case 45..<50:
            return 0.8

        case 71...75:
            return 0.8

        default:
            return 0.6
        }
    }
    
}
